/*******************************************************************************
*                                                                              *
*   PrimeSense NITE 1.3                                                        *
*   Copyright (C) 2010 PrimeSense Ltd.                                         *
*                                                                              *
*******************************************************************************/


#ifndef _XNV_HANDLE_H_
#define _XNV_HANDLE_H_

/**
* Handle for add/remove of Listeners with Generators
*/
typedef XnUInt32 XnVHandle;
static const XnVHandle XN_HANDLE_INVALID = 0;

#endif
