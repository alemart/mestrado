#ifndef OFX_CV_MAIN_H
#define OFX_CV_MAIN_H

/*
*
**** This file is DEPRECATED !!!!!
**** use ofxOpenCv.h instead
*
*/


//--------------------------
// constants
#include "ofxCvConstants.h"

//--------------------------
// images
#include "ofxCvImage.h"
#include "ofxCvGrayscaleImage.h"
#include "ofxCvColorImage.h"
#include "ofxCvFloatImage.h"
#include "ofxCvShortImage.h"

//--------------------------
// contours and blobs
#include "ofxCvContourFinder.h"


#endif
